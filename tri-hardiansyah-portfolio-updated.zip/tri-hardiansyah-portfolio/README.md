# Tri Hardiansyah — Professional Portfolio

Website portofolio statis dengan gaya corporate modern, responsif, bilingual (Indonesia/English), serta tombol dark/light mode.

## Struktur file
- `index.html` — konten dan struktur halaman.
- `styles.css` — tampilan, layout, dan responsive design.
- `script.js` — pergantian bahasa, tema, navigasi mobile, dan scroll indicator.
- `assets/profile-photo.jpg` — tempat foto profil Anda.

## Cara menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` di browser untuk preview.
3. Untuk memasang foto, siapkan foto profil dengan nama `profile-photo.jpg`, lalu letakkan di folder `assets/`. Rasio portrait disarankan 4:5 atau 3:4.
4. Periksa kembali seluruh tanggal, jabatan, metrik, dan tautan eksternal sebelum dipublikasikan.
5. Upload seluruh isi folder ke Netlify, GitHub Pages, atau hosting statis lain. Tidak membutuhkan backend atau proses build.

## Deploy ke Netlify
- Login ke Netlify.
- Pilih **Add new site → Deploy manually**.
- Drag-and-drop folder hasil ekstrak (folder yang berisi `index.html`).
- Netlify akan memberikan URL website.

## Bagian yang perlu Anda verifikasi / lengkapi
- **Foto profil:** foto asli dari website lama tidak berhasil diambil sebagai file gambar dalam proses pembuatan ulang. Tambahkan foto Anda sendiri ke `assets/profile-photo.jpg`.
- **LinkedIn:** tombol saat ini mengarah ke halaman utama LinkedIn; ganti URL pada `index.html` dengan URL profil LinkedIn Anda.
- **Publikasi:** tautan saat ini berupa pencarian judul di ScienceDirect, bukan DOI/URL artikel langsung. Ganti jika Anda memiliki DOI atau URL artikel yang tepat.
- **Spotify:** tautan saat ini berupa pencarian Spotify untuk “Mine Akustik — Beban Keluarga”; ganti dengan URL track langsung jika tersedia.
- **Kontak:** email yang ditampilkan adalah `trihardiansyah389@gmail.com`.
- **Periode pendidikan dan pengalaman:** cocokkan kembali dengan CV terbaru sebelum live.

## Catatan konten
Konten inti yang terbaca dari website portofolio lama telah dimasukkan kembali dan diperluas pada versi ini: profil, pendidikan, pencapaian akademik, seluruh pengalaman kerja/riset/asisten laboratorium, publikasi dan skripsi, proyek musik, organisasi, keahlian, pelatihan, bahasa, software, serta kontak. Beberapa tautan langsung dan aset foto perlu diverifikasi secara manual.


## Update aset dan tautan
Foto profil dan dokumentasi portofolio sudah ditempatkan di folder `assets/`.
Bagian Galeri menampilkan pilihan dokumentasi retail, servis ponsel, laboratorium,
wisuda, organisasi, dan Mine Akustik. Tautan publikasi ScienceDirect, repositori
skripsi UNRI, Spotify, dan LinkedIn telah diperbarui menggunakan tautan yang diberikan.
